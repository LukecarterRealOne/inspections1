# Inspect Items — Smooth Edition (Fabric 1.21.11)

A client-side first-person item inspection mod. Press **G** (rebindable under **Options → Controls → Item Inspect**) to play a randomized flourish for the item in your main hand.

## What's improved

- **Smoother motion:** cubic Hermite keyframe interpolation keeps motion flowing through intermediate keys instead of easing to a stop at every frame.
- **Lower sampling cost:** animation tracks use binary search to locate keyframes.
- **Snappier by default:** default animation speed is 1.2×. The config accepts speeds from 0.5× to 3× and clamps invalid/out-of-range hand offsets.
- **More variety:** added Blade Flourish, Reverse Grip, Tool Check, Heavy Ready, and Relic Reveal animations.
- **Category-specific flair:** swords, axes, tools, maces, spears/tridents, and generic items select from their own animation pools. Registry-path matching also works for many modded items.
- **Clean interruption:** inspections stop when you attack, use an item, open a menu, or switch the held stack.

## Build

Requires **JDK 21**.

```bash
./gradlew build
```

On Windows:

```bat
gradlew.bat build
```

The mod JAR is in `build/libs/` (choose the JAR without `-sources`). To launch a development client, run `./gradlew runClient`.

A GitHub Actions workflow is included at `.github/workflows/build.yml`; push the repository to GitHub and run the **build** workflow, then download the `inspectitems-1.21.11` artifact.

## Config

`config/inspectitems.json` is created on first launch. Change values and restart the game.

- `animationSpeed`: default `1.2`; range `0.5`–`3.0`.
- `hideHandsOutsideInspect`: hide first-person hands except during an inspection.
- `handOffsetX`, `handOffsetY`, `handOffsetZ`: adjust hand placement.
- `handFollow`: `0` keeps the hand fixed; `1` makes it follow the item's animated movement.

Invalid numeric values are replaced with safe defaults and values are clamped to sensible ranges.

## Add or edit animations

Animations live in `src/client/java/dev/inspectitems/client/anim/Animations.java`. Build tracks with `Track.smooth(time, value, ...)` for cubic smooth motion or `Track.linear(time, value, ...)` for straight-line motion. Track time runs from `0` to `1`.

## Build status

The source has been updated, but a local Gradle build could not be completed in this environment because the Gradle distribution could not be downloaded (network/DNS unavailable). Run the included GitHub Actions workflow or build locally to verify against your exact Fabric setup.
