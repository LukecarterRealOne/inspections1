package dev.inspectitems.client.anim;

/** A value over normalized time (0..1) defined by keyframes. Pure Java, no Minecraft types. */
public final class Track {
	public static final Track ZERO = new Track(new float[] {0f, 1f}, new float[] {0f, 0f}, false);

	private final float[] times;
	private final float[] values;
	private final boolean smooth;

	private Track(float[] times, float[] values, boolean smooth) {
		this.times = times;
		this.values = values;
		this.smooth = smooth;
	}

	/** Keys are time,value pairs. Uses smooth cubic interpolation through the keyframes. */
	public static Track smooth(float... keys) {
		return of(keys, true);
	}

	/** Keys are time,value pairs. Straight lines between keys. */
	public static Track linear(float... keys) {
		return of(keys, false);
	}

	private static Track of(float[] keys, boolean smooth) {
		if (keys.length < 4 || keys.length % 2 != 0) {
			throw new IllegalArgumentException("Track needs at least two time,value pairs");
		}
		int n = keys.length / 2;
		float[] t = new float[n];
		float[] v = new float[n];
		for (int i = 0; i < n; i++) {
			t[i] = keys[i * 2];
			v[i] = keys[i * 2 + 1];
			if (i > 0 && t[i] < t[i - 1]) {
				throw new IllegalArgumentException("Track times must not decrease");
			}
		}
		return new Track(t, v, smooth);
	}

	public float at(float time) {
		int last = times.length - 1;
		if (time <= times[0]) return values[0];
		if (time >= times[last]) return values[last];

		// Binary search keeps per-frame animation sampling cheap even with longer tracks.
		int low = 1;
		int high = last;
		while (low < high) {
			int mid = (low + high) >>> 1;
			if (time <= times[mid]) high = mid;
			else low = mid + 1;
		}
		int i = low;
		float span = times[i] - times[i - 1];
		if (span <= 0f) return values[i];
		float u = (time - times[i - 1]) / span;
		if (!smooth) return values[i - 1] + (values[i] - values[i - 1]) * u;

		// Cubic Hermite interpolation keeps motion flowing through intermediate keys
		// instead of easing to a stop at every keyframe.
		float m0 = i == 1 ? 0f : (values[i - 1] - values[i - 2]) / (times[i - 1] - times[i - 2]);
		float m1 = i == last ? 0f : (values[i + 1] - values[i - 1]) / (times[i + 1] - times[i - 1]);
		float u2 = u * u;
		float u3 = u2 * u;
		float h00 = 2f * u3 - 3f * u2 + 1f;
		float h10 = u3 - 2f * u2 + u;
		float h01 = -2f * u3 + 3f * u2;
		float h11 = u3 - u2;
		return h00 * values[i - 1] + h10 * span * m0
			+ h01 * values[i] + h11 * span * m1;
	}
}
